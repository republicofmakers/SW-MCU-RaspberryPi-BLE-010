import time
from machine import Pin, SPI, I2C
from ST7735 import TFT
from sysfont import sysfont
from sht4x import SHT4X
from ble import BluetoothLEConnection

# --- LCD Setup ---
spi = SPI(0, baudrate=20_000_000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)  # dc=21, rst=20, cs=22
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)

# --- LED ---
led = Pin(27, Pin.OUT)
led.value(0)

# --- Sensor (I2C1) ---
i2c = I2C(1, sda=Pin(2), scl=Pin(3), freq=100_000)
sht = SHT4X(i2c)

# --- BLE Class using proven library ---
class BLE(BluetoothLEConnection):
    def advertise_sensor(self, name: str, payload: str):
        name_bytes = name.encode()
        sensor_bytes = payload.encode()

        adv = bytearray()
        adv.append(len(name_bytes) + 1)
        adv.append(0x09)  # Complete Local Name
        adv.extend(name_bytes)

        scan_rsp = bytearray()
        scan_rsp.append(len(sensor_bytes) + 1)
        scan_rsp.append(0xFF)  # Manufacturer specific data
        scan_rsp.extend(sensor_bytes)

        self.do_set_advertise_enable(False)
        self.do_set_advertising_parameters()
        self.do_set_advertising_data(adv)
        self.do_set_scan_response_data(scan_rsp)
        self.do_set_advertise_enable(True)

# --- Init BLE ---
ble = BLE(1)
print("BLE ready")

# --- Welcome screen ---
tft.fill(TFT.BLACK)
tft.text((10, 0), 'BLE TEST', TFT.RED, sysfont, 2)
tft.text((10, 30), 'by Ceyhun', TFT.GREEN, sysfont, 2)
tft.text((10, 60), '2025', TFT.BLUE, sysfont, 2)
time.sleep(2)

# --- Main Loop ---
while True:
    try:
        temp = sht.temperature
        hum = sht.relative_humidity
        msg = "T:{:.1f}C H:{:.1f}%".format(temp, hum)
        print("BLE Adv →", msg)

        # BLE advertise
        ble.advertise_sensor("Ceyhun_PicoW", msg)

        # LCD: TEMP
        tft.fill(TFT.BLACK)
        tft.text((10, 0), 'TEMPERATURE', TFT.RED, sysfont, 2)
        tft.text((10, 30), '{:.2f} C'.format(temp), TFT.GREEN, sysfont, 2)
        time.sleep(2)

        # LCD: HUM
        tft.fill(TFT.BLACK)
        tft.text((10, 0), 'HUMIDITY', TFT.RED, sysfont, 2)
        tft.text((10, 30), '{:.2f} %'.format(hum), TFT.GREEN, sysfont, 2)
        time.sleep(2)

    except Exception as e:
        print("Error:", e)
        tft.fill(TFT.BLACK)
        tft.text((10, 30), 'Error', TFT.RED, sysfont, 2)
        time.sleep(2)
